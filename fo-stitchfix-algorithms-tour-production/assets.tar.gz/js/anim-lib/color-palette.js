
var color_palette = d3.scale.ordinal()
                      .range(["#CCDE66", "#AA7CAA", "#587868", "#F3A54A", "#4B90A6", "#52598B"])
